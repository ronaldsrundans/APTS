# Volvo+Fiat=Motor
Volvo+Fiat=Motor (each letter represents a number)
the main.cpp code finds all possible solutions
